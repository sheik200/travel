/**
 * Created by: Andrey Polyakov (andrey@polyakov.im)
 */

module.exports = {
    devtool: '#cheap-module-source-map',
};
