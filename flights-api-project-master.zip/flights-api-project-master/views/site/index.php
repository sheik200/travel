<?php
$this->title = isset(Yii::$app->params['title'])? Yii::$app->params['title']: '';
?>
<ui-view></ui-view>