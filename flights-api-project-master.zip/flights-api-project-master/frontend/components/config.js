var config = {
    locale: "en",
    marker: 1111,
    type: 'avia_hotel',
    hide_logos: false,
    open_in_new_tab: true,
    default_origin: '',
    default_destination: '',
    lock_destination: false,
    default_hotel_location: '',
};


module.exports = config;